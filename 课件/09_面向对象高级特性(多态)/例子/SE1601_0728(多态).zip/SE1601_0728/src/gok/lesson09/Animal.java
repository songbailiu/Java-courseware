package gok.lesson09;

public class Animal {
	// ����
	
	String name = "Animal";
	
	//��̬��Ա
	static String staticVar = "Animal staticVar";
	
	public void bark() {
		System.out.println("Animal bark()....");

	}
	
	public static void staticFun(){
		System.out.println("Animal ��̬���� staticFun()");
	}
	
	
	
	

}
