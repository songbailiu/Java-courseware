package gok.lesson09;

public class Cat extends Animal {
	String name = "Cat name С��";
	public void bark() {
		System.out.println("Animal bark() ����~~~....");
	}
	
	public void catchMouse() {
		System.out.println("Animal catchMouse() ��רҵ~~~....");

	}
}
