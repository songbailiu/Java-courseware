package gok.lesson09;

public class Pig extends Animal {
	String name = "Pig name";
	public void bark() {
		System.out.println("Pig bark() �ߺ�~~~....");
	}
	
}
