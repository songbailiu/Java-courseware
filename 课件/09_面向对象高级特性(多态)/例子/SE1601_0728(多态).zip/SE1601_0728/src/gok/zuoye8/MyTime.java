package gok.zuoye8;

public class MyTime {
	private int hour, minute, second;

	public MyTime() {
		// TODO Auto-generated constructor stub
	}

	public MyTime(int hour, int minute, int second) {
		super();
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}

	public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public int getMinute() {
		return minute;
	}

	public void setMinute(int minute) {
		this.minute = minute;
	}

	public int getSecond() {
		return second;
	}

	public void setSecond(int second) {
		this.second = second;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return hour+"ʱ"+minute+"��"+second+"��";
	}
	
	public static void main(String[] args) {
		MyTime time1 = new MyTime();
		System.out.println(time1);
		MyTime time2 = new MyTime(10,16,22);
		System.out.println(time2);
		
		
	}

}
