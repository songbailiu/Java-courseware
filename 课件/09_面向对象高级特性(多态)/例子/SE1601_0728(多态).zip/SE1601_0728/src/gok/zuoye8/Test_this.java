package gok.zuoye8;

public class Test_this {
	public static void main(String args[]) {
		Child myC = new Child();
		myC.printall();
	}
}

class Parent {
	void printMe() {
		System.out.println("parent");
	}
}

class Child extends Parent {
	void printMe() {
		System.out.println("child");
	}

	void printall() {
		super.printMe();
		this.printMe();
		printMe();
	}
}
