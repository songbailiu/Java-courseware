package gok.zuoye8;

public class FullTime {
	private MyTime myTime;
	private MyDate myDate;

	public FullTime() {
		myTime = new MyTime();
		myDate = new MyDate();
	}

	public FullTime(MyTime myTime, MyDate myDate) {
		super();
		this.myTime = myTime;
		this.myDate = myDate;
	}

	public MyTime getMyTime() {
		return myTime;
	}

	public void setMyTime(MyTime myTime) {
		this.myTime = myTime;
	}

	public MyDate getMyDate() {
		return myDate;
	}

	public void setMyDate(MyDate myDate) {
		this.myDate = myDate;
	}

	@Override
	public String toString() {
		// ��ʽ�ĵ���ÿһ�������toString() ���ô���
		return myDate + " " + myTime;
	}

	public static void main(String[] args) {

		FullTime fullTime1 = new FullTime();
		System.out.println(fullTime1);

		MyDate date = new MyDate(2012, 12, 22);
		MyTime time = new MyTime(14, 17, 35);
		FullTime fullTime2 = new FullTime(time, date);
		System.out.println(fullTime2);

	}
}
