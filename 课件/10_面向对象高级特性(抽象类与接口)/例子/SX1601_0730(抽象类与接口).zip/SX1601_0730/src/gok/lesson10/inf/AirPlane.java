package gok.lesson10.inf;

public class AirPlane implements FlyInterface {

	@Override
	public void fly() {
		System.out.println("�ɻ� Ҳ�� ��.....");

	}

}
