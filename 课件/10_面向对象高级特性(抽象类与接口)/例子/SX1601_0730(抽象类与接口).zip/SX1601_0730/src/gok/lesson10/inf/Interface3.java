package gok.lesson10.inf;

public interface Interface3 {
	public void funD();

}
