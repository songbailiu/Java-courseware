package gok.lesson10.inf;

public interface Interface4 {
	public void funE();

}
