package gok.lesson10.inf;

/**
 * ��  ���ܽӿ�
 * @author Li
 *
 */
public interface FlyInterface {
	public void fly();

}
