package gok.lesson10.inf;

public class BlackBird extends Bird {
	
	public BlackBird(String name) {
		super(name);
	}

	@Override
	public void fly() {
		System.out.println(getName()+" Ҳ���.....");

	}
	
	
	
	
	

}
