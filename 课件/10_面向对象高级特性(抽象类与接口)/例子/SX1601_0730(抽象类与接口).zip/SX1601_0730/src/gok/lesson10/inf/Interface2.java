package gok.lesson10.inf;

public interface Interface2 {
	public void funC();

}
