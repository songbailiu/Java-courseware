package lesson04;

public class Test05 {
	int age;
	String name;

	public static void main(String[] args) {
		//�������
		int[] arr = new int[2];
		String s = "abc";//������
		String s1 = new String("abc");//���� new
		Object o = new Object();
		System.out.println("o="+o);//java.lang.Object@659e0bfd
		
		Test05 test05Object = new Test05();
		//lesson04.Test05@2a139a55
		System.out.println("test05Object="+test05Object);
		test05Object.age = 20;
		test05Object.name = "Сǿ";
		System.out.println("test05Object.age="+test05Object.age);
		System.out.println("test05Object.name="+test05Object.name);
		
		
		
	}

}
