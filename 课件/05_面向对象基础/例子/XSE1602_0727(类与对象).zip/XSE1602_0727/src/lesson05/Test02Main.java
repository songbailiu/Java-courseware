package lesson05;

public class Test02Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Test02Var.country="+Test02Var.country);
//		System.out.println("country="+country);//error
	}

}
