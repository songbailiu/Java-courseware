package zuoye4;

public class Test04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
////		1
//		int[] arr = new int[1];
//		arr[0] = 1;
//		//2
//		int[] temp = new int[2];//{0,0}
//		temp[1] = 2;
		
		

	}

}
