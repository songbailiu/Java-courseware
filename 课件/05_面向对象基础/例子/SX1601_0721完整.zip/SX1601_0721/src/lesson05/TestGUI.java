package lesson05;

import javax.swing.JFrame;

public class TestGUI {

	public static void main(String[] args) {
		JFrame jFrame1 = new JFrame("����һ");
		jFrame1.setSize(300, 200);
		jFrame1.setLocation(50, 30);
		jFrame1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jFrame1.setVisible(true);
		
		
		JFrame jFrame2 = new JFrame("���ڶ�");
		jFrame2.setSize(300, 200);
		jFrame2.setLocation(350, 30);
		jFrame2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jFrame2.setVisible(true);
	}

}
