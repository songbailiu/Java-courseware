package gok.sx1601.lesson08;

public class Father {
	
	public Father() {
		super();
		System.out.println("1 Father()����...this="+this);
	}
	
	public Father(String name) {
		System.out.println("Father(String name)����...this="+this);
	}
	
	

	String name = "Father name";
	
	public void testFun() {
		System.out.println("Father testFun()...");

	}
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
